// Location.java

public class Location {

}
