// Bordered.java

public interface Bordered {
    public double area();
    public double perimeter();
}
