// Rental.java

public class Rental {
    private Car car;
    private Renter renter;

    public Rental( Car aCar, Renter aRenter ) {
        car = aCar;
        renter = aRenter;
    }

    // ...
}
