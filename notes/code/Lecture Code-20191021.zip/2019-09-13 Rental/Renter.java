// Renter.java

public class Renter {

    // ...
}
