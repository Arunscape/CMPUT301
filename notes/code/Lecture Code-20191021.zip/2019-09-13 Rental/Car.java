// Car.java

public class Car {

    // ...
}
