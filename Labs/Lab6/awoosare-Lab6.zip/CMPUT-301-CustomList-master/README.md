javadoc was generated and is located in the javadoc/ folder
