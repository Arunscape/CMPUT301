# Long press to delete the city. There will be no confirmation
